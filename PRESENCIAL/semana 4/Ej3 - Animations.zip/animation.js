// // Hide the result div

// Hide the result div using fade with 1s duration

// Hide and show the result div using slide

// Hide using slide, wait one second and fade

// Create your own speed and use it

// Set the default animation speed to 2000

// Slide jquery projects and when it's done show on the result div that it's done 

// Move the result div to the bottom left corner

// Move to the left in 10seconds the result div with linear animation

// Create your own function of easing and use it
