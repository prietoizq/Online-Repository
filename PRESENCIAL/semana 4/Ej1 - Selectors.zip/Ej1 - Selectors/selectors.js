// Put a border in the following elements

// all the elements: Example
//$("*").css("border", "solid 1px");

// the div with the id of myContent

// li elements

// li with the basic class

// The first li element with css selectors

// The second li element with traversing filters

// The last p with css selectors

// The last p with traversing filters

// The label element that has an element with the id love

// The li element that has no new class

// The a element with href property is 'http://www.api.jquery.com/'

// The a element with href property starts by http://www.

// The a element with href property contains api

// The p elements

// The p elements inside myContent div

// The parent element to the jquery-ui element

// The siblings to the slogan p

// The p elements not inside myContent div

// The li elements that starts with jQuery. Tip: http://www.w3schools.com/jsref/jsref_substring.asp