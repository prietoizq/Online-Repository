// Change the width of the h1 element

// Change the font-size up to 120%

// Add the hightlighted class to the elements that has the 'new' class

// Remove the title class from h1

// Specify the age range in 20-30

// Specify the age range in 20-30 using travesing filters

// Uncheck the "I love learning" checkbox

// Select yellow as a favourite color

// Write the selected name of the input in the result div

// Write the text of the selected age in the result div

// Writes the number of data likes of jquery-ui in the result div

// Adds 100 to the number of likes and show it in the result div

// Show the absolute position of result in the console

// Move the result to the position 100 top and 150 left

// Change the width and height of the result up to 300px

// Add "(User interface)" after "JQueryUI"

// Add a li element with the text "Future JQ" after jQueryUI

// Add div containers with the class bordered around every li

// Add a div container with the class bordered around all li

// Remove the result div


/**
 *  Final round
 */

// Set the the names of the colours according to their color


// Add links to the li elements, the url is the name ended with .com